//
//  MVINotesUITests.swift
//  MVINotesUITests
//
//  Created by Seng Phrakonkham on 2026. 02. 02..
//

import XCTest
@testable import MVINotesShared

final class MVINotesUITests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    @MainActor
    func testExample() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()

        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    @MainActor
    func testCreateNewNote() throws {
        // GIVEN - Az alkalmazás elindul és látjuk a Notes listát
        let app = XCUIApplication()
        app.launch()
        
        let addNewButton = app.buttons[AccessibilityIds.NoteListViewIds.newNoteButton.rawValue]
        XCTAssertTrue(addNewButton.waitForExistence(timeout: 4))
        
        addNewButton.tap()
        
        let titleTextField = app.textFields[AccessibilityIds.NoteViewIds.titleTextField.rawValue]
        XCTAssertTrue(titleTextField.waitForExistence(timeout: 3))
        titleTextField.tap()
        titleTextField.typeText("UI Test Note")
        
        let saveButton = app.buttons[AccessibilityIds.NoteViewIds.saveButton.rawValue]
        XCTAssertTrue(saveButton.waitForExistence(timeout: 1))
        saveButton.tap()
        
    }
    
    
    @MainActor
    func testNavigateToExistingNote() throws {
        // GIVEN - Az alkalmazás elindul
        let app = XCUIApplication()
        app.launch()
        
        let notesTitle = app.navigationBars["Notes"]
        XCTAssertTrue(notesTitle.waitForExistence(timeout: 3))
        
        // WHEN - Rákattinutunk az első jegyzetre (ha van)
        let firstNote = app.staticTexts.firstMatch
        if firstNote.exists {
            firstNote.tap()
            
            // THEN - Megnyílik a jegyzet részletek képernyő
            // A Back gomb különböző módokon próbálható meg elérni:
            let backButton = app.navigationBars.buttons.element(boundBy: 0)
            XCTAssertTrue(backButton.waitForExistence(timeout: 2), "A Back gombnak meg kell jelennie")
            
            // Visszanavigálunk
            backButton.tap()
            
            // Ellenőrizzük hogy visszajutottunk a listához
            XCTAssertTrue(notesTitle.exists)
        }
    }
    
    @MainActor
    func testBulletPointInsertion() throws {
        // GIVEN - Új jegyzet létrehozása
        let app = XCUIApplication()
        app.launch()
        
        app.buttons["+New"].tap()
        sleep(1)
        
        // WHEN - Felületet aktiváljuk és bullet pontot szúrunk be
        let detailsEditor = app.textViews.firstMatch
        detailsEditor.tap()
        
        // A billentyűzet toolbar-on található bullet gomb
        let bulletButton = app.buttons["list.bullet"]
        if bulletButton.waitForExistence(timeout: 2) {
            bulletButton.tap()
            
            // THEN - Ellenőrizzük hogy beszúródott a bullet karakter
            // (A konkrét szöveg ellenőrzése UI tesztben nehézkes, 
            // de legalább biztosítjuk hogy a gomb működik)
            XCTAssertTrue(detailsEditor.exists)
        }
    }

    @MainActor
    func testLaunchPerformance() throws {
        // This measures how long it takes to launch your application.
        measure(metrics: [XCTApplicationLaunchMetric()]) {
            XCUIApplication().launch()
        }
    }
}
