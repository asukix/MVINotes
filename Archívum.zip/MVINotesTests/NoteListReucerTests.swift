//
//  NoteListReucerTests.swift
//  MVINotes
//
//  Created by Phrakonkham Sengpraseuth on 2026. 03. 12..
//

@testable import MVINotes
import XCTest

class NoteListReucerTests: XCTestCase {
    private var sut: NoteListReducer!
    
    override func setUp() {
        super.setUp()
        sut = .init()
    }
    
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    lazy var noteStub: NoteItemDTO = {
        NoteItemDTO(
            title: "Test",
            summary: "Test summary",
            date: Date(),
            category: .none,
            details: "Test details"
        )
    }()
    
    lazy var noteStub2: NoteItemDTO = {
        NoteItemDTO(
            title: "Different note",
            summary: "Different summary",
            date: Date(),
            category: .none,
            details: "Test details2"
        )
    }()
     
    func test_filter_setFilterMode() {
        // Given
        var state = NoteSummaryState()
        
        // When - filtering by none category
        sut.reduce(
            state: &state,
            result: .filter(.selected(category: NotesCategory.none))
        )
        
        // Then
        XCTAssertEqual(state.filterMode, .none)
        
        // When - filtering by all category
        sut.reduce(
            state: &state,
            result: .filter(.selected(category: NotesCategory.all))
        )
        
        // Then
        XCTAssertEqual(state.filterMode, .all)
        
        // When - filtering by favorites category
        sut.reduce(
            state: &state,
            result: .filter(.selected(category: NotesCategory.favorites))
        )
        
        // Then
        XCTAssertEqual(state.filterMode, .favorites)
    }
    
    
}

// MARK: Add or update reduce tests
extension NoteListReucerTests {
    @MainActor
    func test_add_saveIemToItems() {
        // Given
        let note = noteStub
        var state = NoteSummaryState()
        
        // When
        sut.reduce(
            state: &state,
            result: .addOrUpdate(.addedSuccessfully(item: note))
        )
        
        // Then
        XCTAssertEqual(state.items.count, 1)
        XCTAssertEqual(state.items.first, note)
    }
    
    @MainActor
    func test_add_failedNotAddToItems() {
        // Given
        let note = noteStub
        let note2 = NoteItemDTO(
            title: "Test2",
            summary: "Test summary2",
            date: Date(),
            category: .none,
            details: "Test details2"
        )
        var state = NoteSummaryState(items: [note, note2])
        
        // When
        sut.reduce(
            state: &state,
            result: .addOrUpdate(.addFailed(
                item: note2,
                error: NSError(domain: "", code: 0, userInfo: nil))
            )
        )
        
        // Then
        XCTAssertEqual(state.items.count, 1)
        XCTAssertEqual(state.items.first, note)
    }
}

// MARK: FAvorite reduce tests
extension NoteListReucerTests {
    @MainActor
    func test_setFavorite_updatesItemCategory() {
        // Given
        let note = noteStub
        var state = NoteSummaryState(items: [note])
        
        // When
        sut.reduce(
            state: &state,
            result: .favorite(.settingFavorite(id: note.id, category: .favorites))
        )
        
        // Then
        XCTAssertEqual(state.favoritingItemId, note.id)
        XCTAssertEqual(state.items.first?.category, NotesCategory.favorites)
    }
    
    @MainActor
    func test_setFavorite_whenItemIsNotInState_doesNothing() {
        // Given
        let note = noteStub
        var state = NoteSummaryState(items: [])
        
        // When
        sut.reduce(
            state: &state,
            result: .favorite(.settingFavorite(id: note.id, category: .favorites))
        )
        
        // Then
        XCTAssertNil(state.favoritingItemId)
    }
    
    @MainActor
    func test_setFavorite_whenSettingFavoriteFails_preservesItemCategory() {
        // Given
        let note = noteStub
        var state = NoteSummaryState(items: [note])
        
        // When
        sut.reduce(
            state: &state,
            result: .favorite(.setFavoriteFailed(id: note.id, category: NotesCategory.none, error: NSError(domain: "", code: 0, userInfo: nil)))
        )
        
        // Then
        XCTAssertEqual(state.favoritingItemId, nil)
        XCTAssertEqual(state.items.first?.category, NotesCategory.none)
    }
    
    @MainActor
    func test_setFavorite_whenSettingFavoriteFails_andNoItems_doesNothing() {
        // Given
        var state = NoteSummaryState(items: [])
        
        // When
        sut.reduce(
            state: &state,
            result: .favorite(.setFavoriteFailed(id: UUID(), category: NotesCategory.none, error: NSError(domain: "", code: 0, userInfo: nil)))
        )
        
        // Then
        XCTAssertNil(state.favoritingItemId)
    }
    
    @MainActor
    func test_setFavorite_whenSettingFavoriteFails_andNoSpecificFavoriteIdInState_doesNothing() {
        // Given
        let note = noteStub
        let note2 = noteStub2
        var state = NoteSummaryState(
            items: [note],
            favoritingItemId: note.id
        )
        
        // When
        sut.reduce(
            state: &state,
            result: .favorite(.setFavoriteFailed(id: note2.id, category: NotesCategory.none, error: NSError(domain: "", code: 0, userInfo: nil)))
        )
        
        // Then
        XCTAssertEqual(state.favoritingItemId, note.id)
    }
}

// MARK: Delete reduce tests
extension NoteListReucerTests {
    @MainActor
    func test_delete_removesItemFromItems_andAddsToDeletingItems() {
        // Given
        let note = noteStub
        var state = NoteSummaryState(items: [note])
        
        // When
        sut.reduce(
            state: &state,
            result: .delete(.deleting(id: note.id))
        )
        
        // Then
        XCTAssertTrue(state.items.isEmpty)
        XCTAssertTrue(state.deletingItems.contains(note))
    }
    
    @MainActor
    func test_delete_deleteFailed_addsItemBackToItems() {
        // Given
        let note = noteStub
        var state = NoteSummaryState(
            items: [],
            deletingItems: [note]
        )
        let error = NSError(domain: "Test", code: 0, userInfo: nil)
        
        // When
        sut.reduce(
            state: &state,
            result: .delete(.deleteFailed(id: note.id, error: error))
        )
        
        // Then
        XCTAssertTrue(state.items.contains(note))
        XCTAssertEqual(state.deletingItems.count, 0)
    }
    
    @MainActor
    func test_delete_deleteSucceeded_removesFromDeletingItems() {
        // Given
        let note = noteStub
        var state = NoteSummaryState(deletingItems: [note])
        
        // When
        sut.reduce(
            state: &state,
            result: .delete(.deleteSucceeded(id: note.id))
        )
        
        // Then
        XCTAssertEqual(state.deletingItems, [])
    }
}

// MARK: navigation reduce tests
extension NoteListReucerTests {
    func test_navigation_navigatingToDetail_setsRouteToNoteDetails() {
        // Given
        let note = noteStub
        var state = NoteSummaryState()
        
        // When
        sut.reduce(
            state: &state,
            result: .navigation(.navigatingToDetail(item: note))
        )
        
        // Then
        XCTAssertEqual(state.route, .noteDetails(item: note))
    }
    
    @MainActor
    func test_navigation_navigateBackToList_setsRouteToNil() {
        // Given
        let note = noteStub
        var state = NoteSummaryState(route: .noteDetails(item: note))
        
        // When
        sut.reduce(
            state: &state,
            result: .navigation(.navigateToBackToList)
        )
        
        // Then
        XCTAssertNil(state.route)
    }
}
